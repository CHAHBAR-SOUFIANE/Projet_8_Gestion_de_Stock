# CRUD Example using Ajax-json-jQuery-PHP

## This is Home page
![screen shot 2017-07-14 at 3 32 47 pm](https://user-images.githubusercontent.com/19265196/28208158-0a0343e0-68aa-11e7-953c-dcf92d21130e.png)

## This is Add form
If you click the Down Arrow on Header Area, It will show the Add form. You can add the data whatever you want.      
If you filled the add form, click the Add student button. The data will be added to database and will be showed on Home page. It does without page reloading.

<p align="center">
  <img max-width="500px" height="auto" src="https://user-images.githubusercontent.com/19265196/28208287-947a90aa-68aa-11e7-8dac-217705bf6a76.png">
</p>

## This is Update form
If you click a Update button on any student details , It will show the Update form. You can change the data whatever you want.             
If you changed the data, click the save student button. The data will be saved and updated to database and will be showed on Home page. It does without page reloading.

<p align="center">
  <img max-width="500px" height="auto" src="https://user-images.githubusercontent.com/19265196/28208290-95467cec-68aa-11e7-8855-05ad8fc88988.png">
</p>
